package com.dromedian.bgpoint.hb;

public interface BgPointHbService {
	
	public LogonHbOutputData logonHb(LogonHbInputData logonHbParameters) throws WZApplicationException_Exception;

	public SendSMSOutputData sendSms(SendSMSInputData sendSMSInputData) throws WZApplicationException_Exception;

	public CheckOtpOutputData checkOtp(CheckOtpInputData checkOtpOutputData) throws WZApplicationException_Exception;

	public AperturaRelazioneOutputData aperturaRelazione(AperturaRelazioneInputData aperturaRelazioneInputData) throws WZApplicationException_Exception;
	
	public ChiusuraRelazioneOutputData chiusuraRelazione(ChiusuraRelazioneInputData chiusuraRelazioneInputData) throws WZApplicationException_Exception;

}
