package com.dromedian.bgpoint.hb;

public class BgPointApplication {

	public static void main(String[] args) throws WZApplicationException_Exception {

		BgPointHbService bgPointHbService =new BgPointHbServiceImpl();

		/*+++++++++++++LogOnHb Started++++++++++++++++*/
		//Preparing Input Request input for logonHb
		LogonHbInputData logonHbParameters = new LogonHbInputData();
		EbHbLogonInputData ebHbLogonInputData = new EbHbLogonInputData();

		ebHbLogonInputData.setCircuito("IB");
		ebHbLogonInputData.setIpClient("10.10.10.10");
		ebHbLogonInputData.setPassword("pswpsw02");
		ebHbLogonInputData.setUsername("0000090203");

		logonHbParameters.setLogonHbInputData(ebHbLogonInputData);
		LogonHbOutputData logonHb = bgPointHbService.logonHb(logonHbParameters);

		System.out.println(logonHb);

		/*+++++++++++++LogOnHb Started End++++++++++++++++*/



		/*+++++++++++++Send SMS Started++++++++++++++++*/

		//Preparing Input Request input for Send SMS
		SendSMSInputData sendSMSInputData = new SendSMSInputData();
		SendSMSInputDataT sendSMSInputDataT =new SendSMSInputDataT();
		sendSMSInputDataT.setNumCellulare("3311234567");
		sendSMSInputDataT.setCodApp("BAL0NSC");
		sendSMSInputDataT.setMotivo("Proof Try");
		sendSMSInputDataT.setCdg("111111");
		sendSMSInputData.setSmsInput(sendSMSInputDataT);

		SendSMSOutputData sendSms = bgPointHbService.sendSms(sendSMSInputData);
		System.out.println(sendSms);

		/*+++++++++++++Send SMS END++++++++++++++++*/


		/*+++++++++++++Check OTP Started++++++++++++++++*/

		CheckOtpInputData checkOtpInputData = new CheckOtpInputData();
		CheckOtpInputDataT checkOtpInputDataT = new CheckOtpInputDataT();
		checkOtpInputDataT.setSessionID("sessionid");
		checkOtpInputDataT.setOTP("12345678");
		checkOtpInputData.setCheckOtpInput(checkOtpInputDataT);
		CheckOtpOutputData checkOtp = bgPointHbService.checkOtp(checkOtpInputData);
		System.out.println(checkOtp);

		/*+++++++++++++Check OTP END++++++++++++++++*/



		/*+++++++++++++Apertura Relazione Started++++++++++++++++*/

		//Need some clarification regarding input to set the proper value
		AperturaRelazioneInputData aperturaRelazioneInputData = new AperturaRelazioneInputData();

		AtmInfoT  atmInfoT = new AtmInfoT();
		atmInfoT.setIdPostazione("123");
		atmInfoT.setRequestId("nreq2");

		aperturaRelazioneInputData.setAtminfo(atmInfoT);
		aperturaRelazioneInputData.setCdg(12345);
		aperturaRelazioneInputData.setFgNotizieMK("S");
		aperturaRelazioneInputData.setTipoRelazione("P");
		aperturaRelazioneInputData.setFgRecuperoRapportiAG("S");

		AperturaRelazioneOutputData aperturaRelazione = bgPointHbService.aperturaRelazione(aperturaRelazioneInputData);

		System.out.println(aperturaRelazione);

		/*+++++++++++++Apertura Relazione END++++++++++++++++*/


		/*+++++++++++++chiusura Relazione Started++++++++++++++++*/
		// need some clarification regarding input
		ChiusuraRelazioneInputData chiusuraRelazioneInputData = new ChiusuraRelazioneInputData();
		
		AtmInfoT  atmInfo = new AtmInfoT();
		atmInfoT.setIdPostazione("123");
		atmInfoT.setRequestId("nreq2");
		chiusuraRelazioneInputData.setAtminfo(atmInfo);
		chiusuraRelazioneInputData.setCdg(12345);
		
		ChiusuraRelazioneOutputData chiusuraRelazione = bgPointHbService.chiusuraRelazione(chiusuraRelazioneInputData);
		System.out.println(chiusuraRelazione);
		/*+++++++++++++chiusura Relazione END++++++++++++++++*/


	}

}
