package com.dromedian.bgpoint.hb;

public class BgPointHbServiceImpl implements BgPointHbService {

	BBOperationService service;
	
	public BgPointHbServiceImpl() {
		super();
		BABBOperationService bABBOperationService = new BABBOperationService();
		BBOperationService bbOperationServicePort = bABBOperationService.getBBOperationServicePort();
		this.service = bbOperationServicePort;
	}

	/*
	 * private BBOperationService getInstance() { BABBOperationService
	 * bABBOperationService = new BABBOperationService(); BBOperationService
	 * bbOperationServicePort = bABBOperationService.getBBOperationServicePort();
	 * return bbOperationServicePort; }
	 */

	@Override
	public LogonHbOutputData logonHb(LogonHbInputData logonHbParameters) throws WZApplicationException_Exception {
		return service.logonHb(logonHbParameters);
	}


	@Override
	public SendSMSOutputData sendSms(SendSMSInputData sendSMSRParameters) throws WZApplicationException_Exception {
		return service.sendSms(sendSMSRParameters);
	}


	@Override
	public CheckOtpOutputData checkOtp(CheckOtpInputData checkOtpParameters) throws WZApplicationException_Exception {
		return service.checkOtp(checkOtpParameters);
	}


	@Override
	public AperturaRelazioneOutputData aperturaRelazione(AperturaRelazioneInputData aperturaRelazioneParameters) throws WZApplicationException_Exception {
		
		return service.aperturaRelazione(aperturaRelazioneParameters);
	}

	@Override
	public ChiusuraRelazioneOutputData chiusuraRelazione(ChiusuraRelazioneInputData chiusuraRelazioneParameters)
			throws WZApplicationException_Exception {
		return service.chiusuraRelazione(chiusuraRelazioneParameters);
	}



}
