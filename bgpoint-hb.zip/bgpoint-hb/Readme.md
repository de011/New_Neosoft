[![pipeline status](https://git.dromedian.it/comunico/bgpoint-hb/badges/master/pipeline.svg)](https://git.dromedian.it/comunico/bgpoint-hb/-/commits/master)

[![coverage report](https://git.dromedian.it/comunico/bgpoint-hb/badges/master/coverage.svg)](https://git.dromedian.it/comunico/bgpoint-hb/-/commits/master)



